import React, { useState, useContext } from "react";
import "./PlaceOrder.css";
import { StoreContext } from "../../Context/StoreContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const BASE_DELIVERY_FEE = 17;

const PlaceOrder = () => {
  const [data, setData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    street: "",
    city: "",
    state: "",
    pincode: "",
    country: "مصر",
    phone: "",
  });

  const [customerLocation, setCustomerLocation] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState("cod");
  const [placing, setPlacing] = useState(false);

  const {
    getTotalCartAmount,
    discount,
    food_list = [],
    cartItems = {},
  } = useContext(StoreContext);

  const navigate = useNavigate();
  const subtotal = getTotalCartAmount();
  const deliveryFee = subtotal > 0 ? BASE_DELIVERY_FEE : 0;

  const onChangeHandler = (e) =>
    setData((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const fetchLocation = () => {
    setCustomerLocation({ lat: 30.0444, lng: 31.2357 });
    setData((prev) => ({
      ...prev,
      street: "شارع التحرير، وسط البلد",
      city: "القاهرة",
      state: "القاهرة",
      country: "مصر",
      pincode: "11511",
    }));
    toast.success("تم تحديد الموقع الجغرافي محلياً في النموذج.");
  };

  const placeOrder = (e) => {
    e.preventDefault();

    if (subtotal === 0) {
      toast.warning("سلة التسوق فارغة حالياً. يرجى إضافة أصناف إلى السلة أولاً.");
      return;
    }

    setPlacing(true);

    setTimeout(() => {
      setPlacing(false);
      // As requested: Do not claim order was confirmed without a real backend service.
      toast.info(
        "خدمة إرسال وتأكيد الطلبات غير متصلة بالخادم حالياً (مكتبة واجهات العميل فقط تمهيداً للربط بالنظام)."
      );
    }, 600);
  };

  return (
    <form onSubmit={placeOrder} className="place-order">
      <div className="place-order-left">
        <p className="title">بيانات وعنوان التوصيل</p>

        <div className="multi-fields">
          <input
            required
            name="firstName"
            onChange={onChangeHandler}
            value={data.firstName}
            type="text"
            placeholder="الاسم الأول"
          />
          <input
            required
            name="lastName"
            onChange={onChangeHandler}
            value={data.lastName}
            type="text"
            placeholder="اسم العائلة"
          />
        </div>

        <input
          required
          name="email"
          onChange={onChangeHandler}
          value={data.email}
          type="email"
          placeholder="البريد الإلكتروني"
        />

        <input
          required
          name="street"
          onChange={onChangeHandler}
          value={data.street}
          type="text"
          placeholder="العنوان بالتفصيل (الشارع / رقم المبنى)"
        />

        <div className="multi-fields">
          <input
            required
            name="city"
            onChange={onChangeHandler}
            value={data.city}
            type="text"
            placeholder="المدينة"
          />
          <input
            required
            name="state"
            onChange={onChangeHandler}
            value={data.state}
            type="text"
            placeholder="المحافظة"
          />
        </div>

        <div className="multi-fields">
          <input
            required
            name="pincode"
            onChange={onChangeHandler}
            value={data.pincode}
            type="text"
            placeholder="الرمز البريدي"
          />
          <input
            required
            name="country"
            onChange={onChangeHandler}
            value={data.country}
            type="text"
            placeholder="الدولة"
          />
        </div>

        <input
          required
          name="phone"
          onChange={onChangeHandler}
          value={data.phone}
          type="text"
          placeholder="رقم الهاتف"
        />

        <button
          type="button"
          onClick={fetchLocation}
          className="fetch-location-btn"
        >
          📍 تحديد موقعي الحالي تلقائياً
        </button>

        {customerLocation && (
          <p className="location-success-note">
            ✓ تم التقاط الإحداثيات المحلية
          </p>
        )}
      </div>

      <div className="place-order-right">
        <div className="cart-total">
          <h2>ملخص الفاتورة</h2>

          <div>
            <div className="cart-total-details">
              <p>المجموع الفرعي</p>
              <p>{subtotal} ج.م</p>
            </div>
            <hr />

            {discount > 0 && (
              <>
                <div className="cart-total-details discount-line">
                  <p>خصم الكوبون</p>
                  <p>-{discount} ج.م</p>
                </div>
                <hr />
              </>
            )}

            <div className="cart-total-details">
              <p>رسوم التوصيل</p>
              <p>{deliveryFee} ج.م</p>
            </div>
            <hr />

            <div className="cart-total-details total-bold">
              <b>المبلغ الإجمالي</b>
              <b>{subtotal === 0 ? 0 : Math.max(0, subtotal - discount + deliveryFee)} ج.م</b>
            </div>
          </div>

          <div className="payment-options">
            <h2>طريقة الدفع</h2>

            <div
              className={`payment-option ${
                paymentMethod === "stripe" ? "selected" : ""
              }`}
              onClick={() => setPaymentMethod("stripe")}
            >
              <span className="dot"></span>
              <p>الدفع الإلكتروني عبر البطاقة (فيزا / ماستركارد)</p>
            </div>

            <div
              className={`payment-option ${
                paymentMethod === "cod" ? "selected" : ""
              }`}
              onClick={() => setPaymentMethod("cod")}
            >
              <span className="dot"></span>
              <p>الدفع نقداً عند الاستلام (COD)</p>
            </div>
          </div>

          <button
            type="submit"
            disabled={placing}
            className="place-order-submit-btn"
          >
            {placing ? "جاري المعالجة..." : "تأكيد الطلب 🚀"}
          </button>
        </div>
      </div>
    </form>
  );
};

export default PlaceOrder;
