import React from "react";
import "./Verify.css";
import { Link } from "react-router-dom";

const Verify = () => {
  return (
    <div className="verify-page" style={{ minHeight: "50vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "40px 20px", textAlign: "center" }}>
      <div style={{ maxWidth: "480px", background: "white", padding: "36px 28px", borderRadius: "16px", boxShadow: "0 4px 20px rgba(0,0,0,0.06)", border: "1px solid #f3f4f6" }}>
        <div style={{ fontSize: "48px", marginBottom: "16px" }}>ℹ️</div>
        <h2 style={{ fontSize: "20px", color: "#1a1a2e", marginBottom: "12px", fontWeight: "700" }}>شاشة التحقق من عملية الطلب والدفع</h2>
        <p style={{ color: "#6b7280", fontSize: "14px", lineHeight: "1.6", marginBottom: "24px" }}>
          هذه الشاشة مهيأة بصرياً للتحقق من معاملات الدفع وتأكيد حالة الطلب فور ربط بوابات الدفع الفعلية في نظام طلباتي.
        </p>
        <div style={{ display: "flex", gap: "12px", justifyContent: "center", flexWrap: "wrap" }}>
          <Link to="/" style={{ padding: "10px 20px", borderRadius: "8px", background: "#f3f4f6", color: "#374151", textDecoration: "none", fontWeight: "600", fontSize: "14px" }}>
            العودة للرئيسية
          </Link>
          <Link to="/myorders" style={{ padding: "10px 20px", borderRadius: "8px", background: "#f59e0b", color: "#ffffff", textDecoration: "none", fontWeight: "600", fontSize: "14px" }}>
            قائمة طلباتي ←
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Verify;
