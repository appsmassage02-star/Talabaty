import React, { useContext } from "react";
import "./Profile.css";
import { StoreContext } from "../../Context/StoreContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const Profile = () => {
  const { user, cartItems = {}, setShowLogin } = useContext(StoreContext);
  const navigate = useNavigate();

  const cartCount = Object.values(cartItems || {}).reduce(
    (sum, qty) => sum + qty,
    0
  );

  if (!user) {
    return (
      <div className="profile-page">
        <div className="profile-card" style={{ padding: "48px 24px", textAlign: "center" }}>
          <div style={{ fontSize: "56px", marginBottom: "16px" }}>👤</div>
          <h2 style={{ fontSize: "22px", color: "#1a1a2e", marginBottom: "8px" }}>لا توجد بيانات شخصية متاحة</h2>
          <p style={{ color: "#6b7280", fontSize: "14px", marginBottom: "24px" }}>
            يرجى تسجيل الدخول أو إنشاء حساب لعرض وتعديل ملفك الشخصي وإدارة طلباتك.
          </p>
          <div className="profile-actions" style={{ maxWidth: "320px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "12px" }}>
            <button
              className="profile-btn"
              onClick={() => setShowLogin && setShowLogin(true)}
            >
              تسجيل الدخول / إنشاء حساب
            </button>
            <button
              className="profile-btn"
              style={{ background: "#f3f4f6", color: "#374151" }}
              onClick={() => navigate("/")}
            >
              العودة للرئيسية
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleLogout = () => {
    toast.info("تم تسجيل الخروج");
    navigate("/");
  };

  return (
    <div className="profile-page">
      <div className="profile-card">
        <div className="profile-avatar">
          {user.name?.charAt(0) || "ع"}
        </div>

        <h2>{user.name}</h2>
        <p>{user.email}</p>
      </div>

      <div className="profile-stats">
        <div className="stat-box">
          <h3>{cartCount}</h3>
          <span>عناصر السلة</span>
        </div>

        <div className="stat-box">
          <h3>{user.hasUsedFirstCoupon ? "مُستخدم" : "متاح"}</h3>
          <span>كوبون FIRST15</span>
        </div>
      </div>

      <div className="profile-actions">
        <button
          className="profile-btn"
          onClick={() => navigate("/myorders")}
        >
          📦 طلباتي
        </button>

        <button
          className="profile-btn logout-btn"
          onClick={handleLogout}
        >
          🚪 تسجيل الخروج
        </button>
      </div>
    </div>
  );
};

export default Profile;