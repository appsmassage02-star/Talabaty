import React, { useContext, useState } from "react";
import "./MyOrders.css";
import { StoreContext } from "../../Context/StoreContext";
import { assets } from "../../assets/assets";
import RatingModal from "../../components/RatingModal/RatingModal";
import Swal from "sweetalert2";

const STATUS_STEPS = [
  "Order Placed",
  "Confirmed",
  "Preparing Food",
  "Ready for Pickup",
  "Rider Assigned",
  "Picked Up",
  "Out for Delivery",
  "Delivered",
];

const STATUS_COLOR = {
  "Order Placed": { color: "#d97706", bg: "#fef9c3", dot: "#f59e0b" },
  Confirmed: { color: "#0369a1", bg: "#e0f2fe", dot: "#0ea5e9" },
  "Preparing Food": { color: "#ea580c", bg: "#ffedd5", dot: "#f97316" },
  "Ready for Pickup": { color: "#7c3aed", bg: "#f5f3ff", dot: "#8b5cf6" },
  "Waiting for Rider": { color: "#6b7280", bg: "#f3f4f6", dot: "#9ca3af" },
  "Rider Assigned": { color: "#2563eb", bg: "#eff6ff", dot: "#3b82f6" },
  "Picked Up": { color: "#7c3aed", bg: "#f5f3ff", dot: "#8b5cf6" },
  "Out for Delivery": { color: "#0891b2", bg: "#ecfeff", dot: "#06b6d4" },
  Delivered: { color: "#16a34a", bg: "#dcfce7", dot: "#22c55e" },
  Cancelled: { color: "#991b1b", bg: "#fee2e2", dot: "#ef4444" },
  Rejected: { color: "#991b1b", bg: "#fee2e2", dot: "#ef4444" },
};

const STATUS_TRANSLATIONS = {
  "Order Placed": "تم استلام الطلب",
  "Confirmed": "تم تأكيد الطلب",
  "Preparing Food": "قيد تحضير الطعام",
  "Ready for Pickup": "جاهز للاستلام",
  "Waiting for Rider": "بانتظار مندوب التوصيل",
  "Rider Assigned": "تم تعيين المندوب",
  "Picked Up": "تم استلام الوجبة",
  "Out for Delivery": "مع المندوب في الطريق",
  "Delivered": "تم التوصيل بنجاح",
  "Cancelled": "تم إلغاء الطلب",
  "Rejected": "تم رفض الطلب",
};

const CANCELLABLE_STATUSES = ["Order Placed", "Confirmed", "Preparing Food"];

const canCancel = (order) =>
  CANCELLABLE_STATUSES.includes(order.status) ||
  (order.status === "Waiting for Rider" && order.riderAssignmentFailed);

const MyOrders = () => {
  const { orders = [], setOrders } = useContext(StoreContext);
  const [data, setData] = useState(orders);
  const [ratingOrder, setRatingOrder] = useState(null);
  const [expandedOrder, setExpandedOrder] = useState(null);

  React.useEffect(() => {
    setData(orders);
  }, [orders]);

  const cancelOrder = async (orderId) => {
    const result = await Swal.fire({
      title: "إلغاء الطلب؟",
      text: "هل أنت متأكد من رغبتك في إلغاء هذا الطلب؟",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#ef4444",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "نعم، إلغاء الطلب",
      cancelButtonText: "الاحتفاظ بالطلب",
      reverseButtons: true,
    });

    if (!result.isConfirmed) return;

    setData((prev) =>
      prev.map((o) =>
        o._id === orderId
          ? { ...o, status: "Cancelled", cancelledBy: "customer", refunded: true }
          : o
      )
    );
    if (setOrders) {
      setOrders((prev) =>
        prev.map((o) =>
          o._id === orderId
            ? { ...o, status: "Cancelled", cancelledBy: "customer", refunded: true }
            : o
        )
      );
    }

    await Swal.fire({
      title: "تم الإلغاء!",
      text: "تم إلغاء طلبك بنجاح (معاينة الواجهة).",
      icon: "success",
      timer: 1800,
      showConfirmButton: false,
    });
  };

  if (!data || data.length === 0) {
    return (
      <div className="my-orders">
        <h2>طلباتي</h2>
        <div className="orders-empty">
          <p>🍽</p>
          <h3>لا توجد طلبات بعد</h3>
          <span>ستظهر طلباتك السابقة هنا بمجرد إتمام أول طلب.</span>
        </div>
      </div>
    );
  }

  return (
    <div className="my-orders">
      <div className="my-orders-header">
        <h2>طلباتي</h2>
        <p>
          {data.length} {data.length === 1 ? "طلب" : "طلبات"}
        </p>
      </div>

      <div className="orders-list">
        {data.map((order, index) => {
          const statusStyle =
            STATUS_COLOR[order.status] || STATUS_COLOR["Food Processing"] || { color: "#333", bg: "#eee", dot: "#888" };
          const isDelivered = order.status === "Delivered";
          const isExpanded = expandedOrder === order._id;
          const rider = order.riderId;
          const isCOD = order.paymentMethod === "cod";

          return (
            <div key={order._id || index} className="order-card">
              <div className="order-card-left">
                <div className="order-parcel-icon">
                  <img src={assets.parcel_icon} alt="طلب" />
                </div>
                <div className="order-card-info">
                  <p className="order-items-text">
                    {order.items.map((item, i) =>
                      i === order.items.length - 1
                        ? `${item.name} × ${item.quantity}`
                        : `${item.name} × ${item.quantity}، `,
                    )}
                  </p>
                  <p className="order-meta">
                    {order.items.length} {order.items.length === 1 ? "صنف" : "أصناف"}
                    {" · "}
                    <span className="order-amount">
                      {order.amount.toFixed(2)} ج.م
                    </span>
                    {" · "}
                    {order.refunded ? (
                      <span className="payment-pill refunded">💸 تم استرداد المبلغ</span>
                    ) : isCOD ? (
                      <span
                        className={`payment-pill ${order.payment ? "paid" : "cod-pending"}`}
                      >
                        {order.payment ? "✅ تم الدفع كاش" : "💵 الدفع عند الاستلام"}
                      </span>
                    ) : (
                      <span className="payment-pill paid">💳 مدفوع إلكترونياً</span>
                    )}
                  </p>
                </div>
              </div>

              <div className="order-card-right">
                <div
                  className="order-status-badge"
                  style={{
                    background: statusStyle.bg,
                    color: statusStyle.color,
                  }}
                >
                  <span
                    className="status-dot"
                    style={{ background: statusStyle.dot }}
                  />
                  {STATUS_TRANSLATIONS[order.status] || order.status}
                </div>

                <div className="order-actions">
                  <button
                    className="btn-track"
                    onClick={() => {
                      setExpandedOrder(isExpanded ? null : order._id);
                    }}
                  >
                    {isExpanded ? "إخفاء" : "تتبع الطلب"}
                  </button>

                  {canCancel(order) && (
                    <button
                      className="btn-cancel-order"
                      onClick={() => cancelOrder(order._id)}
                    >
                      إلغاء الطلب
                    </button>
                  )}

                  {isDelivered && (
                    <button
                      className="btn-rate"
                      onClick={() => setRatingOrder(order)}
                    >
                      ⭐ تقييم
                    </button>
                  )}
                </div>
              </div>

              {isExpanded && (
                <div className="order-expanded">
                  {order.riderAssignmentFailed &&
                    order.status === "Waiting for Rider" && (
                      <div className="assignment-failed-banner">
                        ⚠️ نواجه صعوبة في العثور على مندوب توصيل حالياً.
                        يمكنك إلغاء الطلب واسترداد كامل المبلغ أو الانتظار قليلاً.
                      </div>
                    )}
                  {isCOD &&
                    !order.payment &&
                    !["Cancelled", "Rejected"].includes(order.status) && (
                      <div className="cod-banner">
                        💵 يرجى تجهيز مبلغ{" "}
                        <strong>{order.amount.toFixed(2)} ج.م</strong> نقداً لتسليمها لمندوب التوصيل.
                      </div>
                    )}

                  {/* Rider Info Card */}
                  {rider && (
                    <div className="rider-info-card">
                      <img
                        src={
                          rider.profileImage ||
                          `https://ui-avatars.com/api/?name=${encodeURIComponent(rider.name)}&background=f9c400&color=1a1a2e`
                        }
                        alt={rider.name}
                        className="rider-avatar"
                      />
                      <div className="rider-details">
                        <p className="rider-name">🛵 {rider.name}</p>
                        <p className="rider-vehicle">{rider.vehicleNumber}</p>
                      </div>
                      <a href={`tel:${rider.phone}`} className="rider-call-btn">
                        📞 اتصال
                      </a>
                    </div>
                  )}

                  {order.status === "Waiting for Rider" ? (
                    <div className="searching-banner">
                      🔍 جاري البحث عن مندوب توصيل قريب...
                    </div>
                  ) : order.status === "Cancelled" ? (
                    <div className="terminal-banner cancelled">
                      {order.cancelledBy === "system" ? (
                        <>
                          تعذر العثور على مندوب توصيل.
                          <br />
                          تم إلغاء طلبك.
                          <br />
                        </>
                      ) : order.cancelledBy === "customer" ? (
                        <>
                          قمت بإلغاء هذا الطلب.
                          <br />
                        </>
                      ) : (
                        <>
                          تم إلغاء هذا الطلب.
                          <br />
                        </>
                      )}

                      {order.refunded
                        ? "تم بدء إجراءات استرداد المبلغ بنجاح، وسيظهر في حسابك وفق سياسة البنك أو مزود الدفع."
                        : "جاري معالجة استرداد المبلغ."}
                    </div>
                  ) : order.status === "Rejected" ? (
                    <div className="terminal-banner rejected">
                      تعذر على المطعم قبول هذا الطلب في الوقت الحالي.
                      <br />
                      {order.refunded
                        ? "تم بدء إجراءات استرداد المبلغ بنجاح."
                        : "جاري معالجة استرداد المبلغ."}
                    </div>
                  ) : (
                    <div className="order-timeline">
                      {STATUS_STEPS.map((step, i) => {
                        const effectiveStatus =
                          order.status === "Waiting for Rider"
                            ? "Ready for Pickup"
                            : order.status;
                        const stepIdx = STATUS_STEPS.indexOf(effectiveStatus);
                        const isDone = i <= stepIdx;
                        const isCurrent = i === stepIdx;
                        return (
                          <div
                            key={step}
                            className={`timeline-step ${isDone ? "done" : ""} ${isCurrent ? "current" : ""}`}
                          >
                            <div className="timeline-dot">
                              {isDone ? "✓" : ""}
                            </div>
                            <div className="timeline-line" />
                            <span className="timeline-label">{STATUS_TRANSLATIONS[step] || step}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {ratingOrder && (
        <RatingModal
          order={ratingOrder}
          onClose={() => setRatingOrder(null)}
        />
      )}
    </div>
  );
};

export default MyOrders;
