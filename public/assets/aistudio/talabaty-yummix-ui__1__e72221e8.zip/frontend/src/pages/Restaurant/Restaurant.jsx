import React, { useContext } from "react";
import { useParams } from "react-router-dom";
import FoodDisplay from "../../components/FoodDisplay/FoodDisplay";
import "./Restaurant.css";
import verify from "../../assets/verify.png";
import { StoreContext } from "../../Context/StoreContext"; 

const Restaurant = () => {
  const { id } = useParams();
  const { restaurants = [], food_list = [] } = useContext(StoreContext);

  const currentRestaurant = restaurants.find((r) => r._id === id);

  if (!currentRestaurant) {
    return (
      <div className="restaurant-page">
        <div className="empty-restaurant-state" style={{ textAlign: "center", padding: "64px 20px" }}>
          <div style={{ fontSize: "48px", marginBottom: "16px" }}>🏪</div>
          <h2 style={{ fontSize: "22px", color: "#1a1a2e", marginBottom: "8px" }}>لا توجد بيانات مطعم متاحة حالياً</h2>
          <p style={{ color: "#6b7280", fontSize: "14px" }}>
            سيتم عرض بيانات المطعم وقائمة أطباقه فور ربطها بنظام طلباتي.
          </p>
        </div>
      </div>
    );
  }

  const restaurantFoods = food_list.filter((f) => f.restaurantId === id);

  return (
    <div className="restaurant-page">
      <div className="restaurant-header">
        <div className="restaurant-name-box">
          <h1>{currentRestaurant.restaurantName}</h1>
          {currentRestaurant.isApproved && (
            <img src={verify} alt="موثق ومعتمد" className="restaurant-verified" />
          )}
        </div>
        <p>{currentRestaurant.address}</p>
      </div>

      <FoodDisplay
        category="All"
        foods={restaurantFoods}
        restaurantName={currentRestaurant.restaurantName}
      />
    </div>
  );
};

export default Restaurant;
