import React from "react";
import "./About.css";
import { useNavigate } from "react-router-dom";

const About = () => {
  const navigate = useNavigate();
  return (
    <div className="about">
      <div className="about-hero">
        <h1>عن طلباتي</h1>
        <p>طعامك المفضل، يصلك طازجاً وبأقصى سرعة.</p>
      </div>
      <div className="about-section">
        <h2>قصتنا</h2>
        <p>تأسست طلباتي بهدف واحد أساسي — جعل طلب الطعام تجربة سهلة وممتعة. من أشهى الأطباق الشعبية إلى المطاعم الفاخرة، نجمع كل نكهاتك المفضلة بين يديك.</p>
      </div>
      <div className="about-section">
        <h2>رسالتنا</h2>
        <p>نعمل على ربطك بأفضل المطاعم المحلية، مع ضمان التوصيل السريع والجودة العالية وتجربة استخدام رقمية لا مثيل لها.</p>
      </div>
      <div className="about-features">
        <h2>لماذا تختار طلباتي؟</h2>
        <div className="features-grid">
          <div className="feature-card"><h3>⚡ توصيل سريع</h3><p>استلم طعامك ساخناً وطازجاً في أقصر وقت ممكن.</p></div>
          <div className="feature-card"><h3>🍽 تنوع كبير</h3><p>استكشف مئات الأطباق والمطابخ المختلفة.</p></div>
          <div className="feature-card"><h3>📱 طلب سهل وممتع</h3><p>واجهة وتطبيق سلس لتجربة طلب فورية ومريحة.</p></div>
          <div className="feature-card"><h3>💳 دفع آمن ومتنوع</h3><p>وسائل دفع إلكترونية متعددة وخيار الدفع عند الاستلام.</p></div>
        </div>
      </div>
      <div className="about-stats">
        <div><h2>+10 آلاف</h2><p>طلب ناجح</p></div>
        <div><h2>+500</h2><p>مطعم شريك</p></div>
        <div><h2>+50 ألف</h2><p>عميل سعيد</p></div>
      </div>
      <div className="about-cta">
        <h2>مستعد لاكتشاف أشهى الوجبات؟</h2>
        <button onClick={() => navigate("/")}>اطلب الآن</button>
      </div>
    </div>
  );
};
export default About;
