import React, { useState } from "react";
import "./Feedback.css";
import { toast } from "react-toastify";

const INITIAL = {
  name: "",
  email: "",
  rating: "",
  message: "",
};

const Feedback = () => {
  const [form, setForm] = useState(INITIAL);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast.success("شكراً جزيلاً لمشاركتنا رأيك (معاينة الواجهة)! 🙌");
    setForm(INITIAL);
  };

  return (
    <div className="feedback">
      <div className="feedback-hero">
        <h1>رأيك يهمنا جداً</h1>
        <p>ساعدنا في تحسين وتطوير تجربة طلباتي باستمرار.</p>
      </div>

      <div className="feedback-form">
        <h2>شاركنا تجربتك</h2>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="الاسم الكامل"
            value={form.name}
            onChange={handleChange}
            required
          />

          <input
            type="email"
            name="email"
            placeholder="البريد الإلكتروني"
            value={form.email}
            onChange={handleChange}
            required
          />

          <select
            name="rating"
            value={form.rating}
            onChange={handleChange}
            required
          >
            <option value="">اختر التقييم</option>
            <option value="5">⭐⭐⭐⭐⭐ ممتاز جداً</option>
            <option value="4">⭐⭐⭐⭐ جيد جداً</option>
            <option value="3">⭐⭐⭐ متوسط</option>
            <option value="2">⭐⭐ ضعيف</option>
            <option value="1">⭐ سيء للغاية</option>
          </select>

          <textarea
            name="message"
            placeholder="اكتب ملاحظاتك أو اقتراحاتك هنا..."
            value={form.message}
            onChange={handleChange}
            required
          />

          <button type="submit">إرسال الرأي</button>
        </form>
      </div>
    </div>
  );
};

export default Feedback;