import React from "react";
import "./Delivery.css";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const Delivery = () => {
  const navigate = useNavigate();

  return (
    <div className="delivery">
      <div className="delivery-hero">
        <h1>توصيل سريع وموثوق</h1>
        <p>وجبات ساخنة وطازجة تصل حتى باب بيتك، في أي وقت وأينما كنت.</p>
      </div>

      <div className="delivery-section">
        <h2>كيف يعمل التوصيل؟</h2>

        <div className="steps">
          <div className="step">
            <h3>🛒 اختر طعامك واطلب</h3>
            <p>حدد أطباقك المفضلة وأكمل طلبك في ثوانٍ معدودة.</p>
          </div>

          <div className="step">
            <h3>👨‍🍳 تحضير المطعم</h3>
            <p>يقوم المطعم بتحضير طعامك طازجاً وبأعلى معايير النظافة والجودة.</p>
          </div>

          <div className="step">
            <h3>🛵 التوصيل إليك</h3>
            <p>يقوم مندوبنا المعتمد بتوصيل الوجبة بكل أمان وسرعة إلى باب منزلك.</p>
          </div>
        </div>
      </div>

      <div className="delivery-features">
        <h2>لماذا تختار التوصيل عبر طلباتي؟</h2>

        <div className="features-grid">
          <div className="feature-card">
            <h3>⚡ فائق السرعة</h3>
            <p>توصيل سريع بفضل التوجيه الذكي وتعيين أقرب مندوب.</p>
          </div>

          <div className="feature-card">
            <h3>📍 تتبع مباشر</h3>
            <p>تابع مسار طلبك وموقع المندوب خطوة بخطوة في الوقت الفعلي.</p>
          </div>

          <div className="feature-card">
            <h3>🛡 توصيل آمن وموثوق</h3>
            <p>مناديب معتمدون وتغليف محكم يحافظ على جودة وسلامة الطعام.</p>
          </div>

          <div className="feature-card">
            <h3>💰 أسعار وتكاليف مناسبة</h3>
            <p>رسوم توصيل معقولة مع عروض حصرية وخصومات متجددة.</p>
          </div>
        </div>
      </div>

      <div className="delivery-section">
        <h2>مناطق التوصيل</h2>

        <p>
          نتوسع باستمرار لتغطية مختلف الأحياء والمناطق لنقدم خدمة توصيل سريعة وموثوقة لجميع عملائنا.
        </p>
      </div>

      <div className="delivery-partner">
        <h2>انضم إلينا كمندوب توصيل</h2>

        <p>
          حقق دخلاً إضافياً في أوقات فراغك وبمرونة تامة. انضم لفريق توصيل طلباتي وتابع أرباحك ورحلاتك عبر بوابة المندوب.
        </p>

        <button
          onClick={() => toast.info("بوابة مناديب التوصيل قيد الإعداد لنظام طلباتي.")}
          className="delivery-btn"
          style={{ border: "none", cursor: "pointer" }}
        >
          انضم كشريك توصيل ←
        </button>
      </div>

      <div className="delivery-cta">
        <h2>تشعر بالجوع؟ اطلب وجبتك المفضلة الآن!</h2>

        <button onClick={() => navigate("/")}>
          اطلب الآن
        </button>
      </div>
    </div>
  );
};

export default Delivery;