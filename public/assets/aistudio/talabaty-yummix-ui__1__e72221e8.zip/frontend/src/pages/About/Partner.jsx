import React from "react";
import "./Partner.css";
import { toast } from "react-toastify";

const Partner = () => {
  return (
    <div className="partner">
      <div className="partner-hero">
        <h1>انضم كشريك إلى طلباتي</h1>
        <p>
          انضم لمئات المطاعم التي تنمي أعمالها وتزيد مبيعاتها مع طلباتي.
        </p>
      </div>

      <div className="partner-section">
        <h2>لماذا تشارك مطعمك معنا؟</h2>

        <div className="partner-features">
          <div className="feature-card">
            <h3>📈 زيادة المبيعات</h3>
            <p>صل إلى آلاف العملاء الجدد وضاعف إيرادات مطعمك اليومية.</p>
          </div>

          <div className="feature-card">
            <h3>🚀 انضمام سهل وسريع</h3>
            <p>سجّل مطعمك وابدأ في استقبال الطلبات في وقت قياسي.</p>
          </div>

          <div className="feature-card">
            <h3>🛵 أسطول توصيل متكامل</h3>
            <p>شبكة مناديب محترفة تتكفل بتوصيل طلباتك للزبائن بسرعة وأمان.</p>
          </div>

          <div className="feature-card">
            <h3>📊 لوحة تحكم متطورة</h3>
            <p>
              تحكم في قائمة الطعام، الطلبات، الإحصائيات، الكوبونات والتقارير من مكان واحد.
            </p>
          </div>
        </div>
      </div>

      <div className="partner-cta">
        <h2>جاهز للانضمام إلى طلباتي؟</h2>

        <p>
          سجّل مطعمك وأدر قائمة أطباقك واستقبل الطلبات بسهولة عبر بوابة مطاعم طلباتي.
        </p>

        <button
          onClick={() => toast.info("بوابة الشركاء قيد الإعداد لنظام طلباتي.")}
          className="partner-btn"
          style={{ border: "none", cursor: "pointer" }}
        >
          سجّل مطعمك الآن ←
        </button>
      </div>
    </div>
  );
};

export default Partner;