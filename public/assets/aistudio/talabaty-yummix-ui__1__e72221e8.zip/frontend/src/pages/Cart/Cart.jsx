import React, { useContext, useEffect, useState } from "react";
import "./Cart.css";
import { StoreContext } from "../../Context/StoreContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const haversineKm = (lat1, lng1, lat2, lng2) => {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
};

const BASE_DELIVERY_FEE = 17;
const PER_KM_DELIVERY_RATE = 4;
const FREE_KM_THRESHOLD = 2;

const calcDeliveryFee = (userLocation, nearestRestaurant) => {
  if (  userLocation?.lat == null ||  nearestRestaurant?.location?.lat == null) {
    return BASE_DELIVERY_FEE;
  }
  const distKm = haversineKm(
    userLocation.lat,
    userLocation.lng,
    nearestRestaurant.location.lat,
    nearestRestaurant.location.lng,
  );
  const extraKm = Math.max(0, distKm - FREE_KM_THRESHOLD);
  return Math.round(BASE_DELIVERY_FEE + extraKm * PER_KM_DELIVERY_RATE);
};

const Cart = () => {
  const {
    cartItems,
    food_list,
    removeFromCart,
    getTotalCartAmount,
    discount,
    setDiscount,
    couponCode,
    setCouponCode,
    userLocation,
    nearbyRestaurants,
    restaurants,
  } = useContext(StoreContext);

  const navigate = useNavigate();
  const subtotal = getTotalCartAmount();

  const cartFoodId = Object.keys(cartItems).find((id) => cartItems[id] > 0);
  const cartFood = food_list.find((f) => f._id === cartFoodId);
  const cartRestaurant = restaurants.find(
    (r) => r._id === cartFood?.restaurantId,
  );

  const deliveryFee =
    subtotal === 0 ? 0 : calcDeliveryFee(userLocation, cartRestaurant);

  useEffect(() => {
    if (couponCode.trim().toUpperCase() === "FIRST15" && discount > 0) {
      setDiscount(subtotal * 0.15);
    }
  }, [subtotal, couponCode, setDiscount]);

  const applyCoupon = () => {
    if (couponCode.trim().toUpperCase() === "FIRST15") {
      if (discount > 0) return toast.info("تم تطبيق الكوبون مسبقاً");
      setDiscount(subtotal * 0.15);
      toast.success("تم تطبيق خصم 15% بنجاح!");
    } else {
      toast.error("رمز الكوبون غير صالح");
    }
  };

  const discountedTotal =
    subtotal === 0 ? 0 : (subtotal - discount + deliveryFee).toFixed(2);

  const hasItems = food_list.some((item) => cartItems[item._id] > 0);

  if (!hasItems) {
    return (
      <div className="cart-empty">
        <div className="cart-empty-card">
          <div className="cart-empty-icon">🛒</div>

          <h2>سلة مشترياتك فارغة حالياً</h2>

          <p>
            استكشف أشهى المأكولات والأطباق من أفضل المطاعم القريبة وابدأ بطلب وجبتك الآن.
          </p>

          <div className="cart-empty-features">
            <span>🍔 طعام طازج وساخن</span>
            <span>⚡ توصيل فائق السرعة</span>
            <span>🎁 عروض وخصومات مميزة</span>
          </div>

          <button
            className="cart-empty-btn"
            onClick={() => {
              document.body.classList.add("page-leaving");
              setTimeout(() => {
                navigate("/");
              }, 200);
            }}
          >
            تصفح القائمة الآن
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="cart">
      <div className="cart-items">
        <div className="cart-items-title">
          <p>الصورة</p>
          <p>الوجبة</p>
          <p>السعر</p>
          <p>الكمية</p>
          <p>المجموع</p>
          <p>حذف</p>
        </div>
        <br />
        <hr />
        {food_list.map((item) => {
          if (!cartItems[item._id]) return null;
          return (
            <div key={item._id}>
              <div className="cart-items-title cart-items-item">
                <img src={item.image} alt={item.name} />
                <p>{item.name}</p>
                <p>{item.price.toFixed(2)} ج.م</p>
                <div>{cartItems[item._id]}</div>
                <p>{(item.price * cartItems[item._id]).toFixed(2)} ج.م</p>
                <p
                  className="cart-items-remove-icon cross"
                  onClick={() => removeFromCart(item._id)}
                  title="حذف من السلة"
                >
                  ✕
                </p>
              </div>
              <hr />
            </div>
          );
        })}
      </div>

      <div className="cart-bottom">
        <div className="cart-total">
          <h2>إجمالي الحساب</h2>
          <div>
            <div className="cart-total-details">
              <p>المجموع الفرعي</p>
              <p>{subtotal} ج.م</p>
            </div>
            <br />
            <div className="cart-total-details">
              <p>رسوم التوصيل</p>
              <div>
                <p>{deliveryFee} ج.م</p>
                {cartRestaurant?.location?.lat && userLocation?.lat && (
                  <p style={{ fontSize: 11, color: "#9ca3af", marginTop: 2 }}>
                    محسوبة حسب المسافة من {cartRestaurant.restaurantName}
                  </p>
                )}
                {!cartRestaurant?.location?.lat && (
                  <p style={{ fontSize: 11, color: "#f59e0b", marginTop: 2 }}>
                    توصيل قياسي ثابت
                  </p>
                )}
              </div>
            </div>
            {discount > 0 && (
              <>
                <hr />
                <div className="cart-total-details">
                  <p>خصم الكوبون (15%)</p>
                  <p>-{discount.toFixed(2)} ج.م</p>
                </div>
              </>
            )}
            <hr />
            <div className="cart-total-details">
              <b>المجموع الكلي</b>
              <b>{discountedTotal} ج.م</b>
            </div>
          </div>
          <button onClick={() => navigate("/order")}>
            المتابعة لإتمام الطلب
          </button>
        </div>

        <div className="cart-promocode">
          <p>هل لديك كود خصم؟</p>
          <div className="cart-promocode-input">
            <input
              type="text"
              placeholder="أدخل رمز الكوبون (مثال: FIRST15)"
              value={couponCode}
              onChange={(e) => {
                setCouponCode(e.target.value);
                if (e.target.value.trim().toUpperCase() !== "FIRST15") {
                  setDiscount(0);
                }
              }}
            />
            <button onClick={applyCoupon}>تطبيق</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
