import React from 'react'
import './Footer.css'
import { assets } from '../../assets/assets'
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <div className='footer' id='footer'>
      <div className="footer-content">
        <div className="footer-content-left">
            <img src={assets.logo} alt="طلباتي" />
            <p>رحلتك لأشهى المأكولات تبدأ بنقرة واحدة! اطلب الآن ودلّل حواسك بألذ النكهات مع أسرع توصيل.</p>
            <div className="footer-social-icons">
                <img src={assets.facebook_icon} alt="فيسبوك" />
                <img src={assets.twitter_icon} alt="تويتر" />
                <img src={assets.linkedin_icon} alt="لينكد إن" />
            </div>
        </div>
        <div className="footer-content-center">
            <h2>روابط سريعة</h2>
            <ul>
            <li><Link to="/">الرئيسية</Link></li>
            <li><Link to="/about">من نحن</Link></li>
            <li><Link to="/delivery">خدمة التوصيل</Link></li>
            <li><Link to="/partner">انضم كشريك</Link></li>
            <li><Link to="/feedback">آراء العملاء وملاحظاتهم</Link></li>
            <li><Link to="/privacy">سياسة الخصوصية</Link></li>
            <li><Link to="/terms">الشروط والأحكام</Link></li>
            </ul>
        </div>
        <div className="footer-content-right">
            <h2>الدعم والمساعدة</h2>
            <ul>
                <li>خدمة العملاء: 19000</li>
                <li>support@talabaty.com</li>
                <li>المحادثة الفورية والمساعدة</li>
            </ul>
        </div>
      </div>
      <hr />
      <p className="footer-copyright">جميع الحقوق محفوظة © 2026 طلباتي - Talabaty</p>
    </div>
  )
}

export default Footer
