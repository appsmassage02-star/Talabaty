import React, { useState, useEffect } from 'react';
import './Header.css';

const Header = () => {
  const [current, setCurrent] = useState(0);
  const [transition, setTransition] = useState(true);

  const banners = [
    {
      bg: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
      showText: true,
      title: "أشهى الوجبات في أي وقت وأي مكان",
      desc: "اطلب وجباتك المفضلة لتصلك طازجة وسريعة حتى باب بيتك مع طلباتي!",
      promo: "خصم 15% خاص بالطلب الأول",
      code: "استخدم الكود: FIRST15",
    },
    {
      bg: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
      showText: true,
      title: "توصيل سريع ومطاعم موثوقة",
      desc: "اختر من بين تشكيلة متنوعة من أفضل المطاعم القريبة منك مع تتبع مباشر للطلب.",
      promo: "توصيل مجاني للطلبات المؤهلة",
      code: "عروض يومية متجددة",
    },
    {
      bg: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
      showText: true,
      title: "تجربة طلب سهلة ومريحة",
      desc: "أضف أطباقك المفضلة إلى السلة واستمتع بتجربة دفع وتوصيل سلسة.",
      promo: "خدمة عملاء على مدار الساعة",
      code: "طعام طازج حتى باب بيتك",
    }
  ];

  const slides = [...banners, banners[0]];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => prev + 1);
    }, 5000);

    return () => clearInterval(interval);
  }, [banners.length]);

  useEffect(() => {
    if (current === banners.length) {
      setTimeout(() => {
        setTransition(false);
        setCurrent(0);
      }, 700);

      setTimeout(() => {
        setTransition(true);
      }, 750);
    }
  }, [current, banners.length]);

  return (
    <div className="header">
      <div
        className="slider-track"
        style={{
          transform: `translateX(-${current * 100}%)`,
          transition: transition ? 'transform 0.7s ease-in-out' : 'none'
        }}
      >
        {slides.map((banner, index) => (
          <div
            key={index}
            className="slide"
            style={{ background: banner.bg }}
          >
            {banner.showText && index !== banners.length && (
              <div className="header-contents">
                <h2>{banner.title}</h2>
                <p>{banner.desc}</p>
                <h4>{banner.promo}</h4>
                <h3>{banner.code}</h3>
                <button onClick={() => document.getElementById("explore-menu")?.scrollIntoView({ behavior: "smooth" })}>
                  استعرض القائمة
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* DOTS */}
      <div className="dots">
        {banners.map((_, index) => (
          <span
            key={index}
            className={current % banners.length === index ? "dot active" : "dot"}
            onClick={() => setCurrent(index)}
          ></span>
        ))}
      </div>
    </div>
  );
};

export default Header;