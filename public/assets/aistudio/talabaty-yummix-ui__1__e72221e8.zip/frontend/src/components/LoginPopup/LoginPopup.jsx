import React, { useState } from "react";
import "./LoginPopup.css";
import { assets } from "../../assets/assets";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const LoginPopup = ({ setShowLogin }) => {
  const [currState, setCurrState] = useState("Sign Up");
  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const onChangeHandler = (e) =>
    setData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));

  const onLogin = (e) => {
    e.preventDefault();
    // Pure UI library: Do not pretend user logged in without real authentication backend.
    toast.info(
      "خدمة تسجيل الدخول والمصادقة غير متصلة بالخادم حالياً (مكتبة واجهات العميل فقط تمهيداً للربط بالنظام)."
    );
    setShowLogin(false);
  };

  const goToPage = (path) => {
    setShowLogin(false);
    navigate(path);
  };

  return (
    <div className="login-popup">
      <form onSubmit={onLogin} className="login-popup-container">
        <div className="login-popup-title">
          <h2>{currState === "Login" ? "تسجيل الدخول" : "إنشاء حساب جديد"}</h2>

          <img
            onClick={() => setShowLogin(false)}
            src={assets.cross_icon}
            alt="إغلاق"
          />
        </div>

        <div className="login-popup-inputs">
          {currState === "Sign Up" && (
            <input
              type="text"
              name="name"
              placeholder="اسمك الكامل"
              value={data.name}
              onChange={onChangeHandler}
              required
            />
          )}

          <input
            type="email"
            name="email"
            placeholder="البريد الإلكتروني"
            value={data.email}
            onChange={onChangeHandler}
            required
          />

          <input
            type="password"
            name="password"
            placeholder="كلمة المرور"
            value={data.password}
            onChange={onChangeHandler}
            required
          />
        </div>

        <button type="submit">
          {currState === "Login" ? "تسجيل الدخول" : "إنشاء حساب"}
        </button>

        <div className="login-popup-condition">
          <input type="checkbox" required />

          <p>
            بالمتابعة، أنت توافق على{" "}
            <span onClick={() => goToPage("/terms")}>
              شروط الاستخدام
            </span>
            {" و "}
            <span onClick={() => goToPage("/privacy")}>
              سياسة الخصوصية
            </span>
            .
          </p>
        </div>

        {currState === "Login" ? (
          <p>
            ليس لديك حساب بعد؟{" "}
            <span onClick={() => setCurrState("Sign Up")}>
              أنشئ حساباً الآن
            </span>
          </p>
        ) : (
          <p>
            لديك حساب بالفعل؟{" "}
            <span onClick={() => setCurrState("Login")}>
              سجّل الدخول هنا
            </span>
          </p>
        )}
      </form>
    </div>
  );
};

export default LoginPopup;