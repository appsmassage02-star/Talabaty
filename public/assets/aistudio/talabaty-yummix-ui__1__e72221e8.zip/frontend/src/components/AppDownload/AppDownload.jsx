import React from 'react'
import './AppDownload.css'
import { assets } from '../../assets/assets'

const AppDownload = () => {
    return (
        <div className='app-download' id='app-download'>
            <p>حمّل تطبيق طلباتي الآن!</p>
            <h6>استمتع بتجربة طلب وتوصيل طعام فائقة السرعة والسهولة</h6>
            <div className="app-download-platforms">
                <img src={assets.play_store} alt="Google Play" />
                <img src={assets.app_store} alt="App Store" />
            </div>
        </div>
    )
}

export default AppDownload
