import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./UIShowcaseBar.css";

const screens = [
  { path: "/", label: "🏠 الرئيسية" },
  { path: "/menu", label: "🍔 القائمة" },
  { path: "/restaurant/res_1", label: "🍴 صفحة المطعم" },
  { path: "/cart", label: "🛒 السلة" },
  { path: "/order", label: "💳 إتمام الطلب" },
  { path: "/myorders", label: "📦 طلباتي والتتبع" },
  { path: "/profile", label: "👤 الملف الشخصي" },
  { path: "/about", label: "ℹ️ من نحن" },
  { path: "/delivery", label: "🛵 التوصيل" },
  { path: "/partner", label: "🤝 الشركاء" },
  { path: "/feedback", label: "💬 الملاحظات" },
  { path: "/terms", label: "📜 الشروط" },
  { path: "/privacy", label: "🔒 الخصوصية" },
];

const UIShowcaseBar = ({ onOpenLogin, onOpenRating }) => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  return (
    <div className={`ui-showcase-bar ${collapsed ? "collapsed" : ""}`}>
      <div className="ui-showcase-header">
        <div className="ui-showcase-title">
          <span className="badge">مكتبة واجهات تطبيق العميل (طلباتي)</span>
          <span className="desc">معاينة بصرية مستقلة لجميع الشاشات والمكونات</span>
        </div>
        <div className="ui-showcase-actions">
          <button
            type="button"
            className="action-pill-btn"
            onClick={onOpenLogin}
          >
            🪟 نافذة تسجيل الدخول
          </button>
          <button
            type="button"
            className="action-pill-btn"
            onClick={onOpenRating}
          >
            ⭐ نافذة التقييم
          </button>
          <button
            type="button"
            className="toggle-collapse-btn"
            onClick={() => setCollapsed(!collapsed)}
            title={collapsed ? "توسيع الشريط" : "تصغير الشريط"}
          >
            {collapsed ? "عرض قائمة الشاشات ▼" : "إخفاء ▲"}
          </button>
        </div>
      </div>

      {!collapsed && (
        <div className="ui-showcase-links">
          {screens.map((screen) => {
            const isActive = location.pathname === screen.path;
            return (
              <Link
                key={screen.path}
                to={screen.path}
                className={`showcase-link ${isActive ? "active" : ""}`}
              >
                {screen.label}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default UIShowcaseBar;
