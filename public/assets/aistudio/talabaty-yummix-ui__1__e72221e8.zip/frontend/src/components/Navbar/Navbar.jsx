import React, { useContext, useEffect, useState } from "react";
import "./Navbar.css";
import { assets } from "../../assets/assets";
import { Link, useNavigate } from "react-router-dom";
import { StoreContext } from "../../Context/StoreContext";

const Navbar = ({ setShowLogin, setSearchQuery }) => {
  const [menu, setMenu] = useState("home");
  const [showSearch, setShowSearch] = useState(false);
  const [placeholder, setPlaceholder] = useState("");

  useEffect(() => {
    const words = ["طعامك المفضل...", "أفضل المطاعم...", "وجبة سريعة...", "المشروبات والحلويات..."];
    let wordIndex = 0;
    let charIndex = 0;
    let isDeleting = false;

    const typing = setInterval(() => {
      const currentWord = words[wordIndex];

      if (!isDeleting) {
        setPlaceholder(currentWord.substring(0, charIndex + 1));
        charIndex++;

        if (charIndex === currentWord.length) {
          isDeleting = true;
        }
      } else {
        setPlaceholder(currentWord.substring(0, charIndex - 1));
        charIndex--;

        if (charIndex === 0) {
          isDeleting = false;
          wordIndex = (wordIndex + 1) % words.length;
        }
      }
    }, 220);

    return () => clearInterval(typing);
  }, []);

  const { getTotalCartAmount, user, setUser } = useContext(StoreContext);
  const navigate = useNavigate();

  return (
    <div className="navbar">
      <Link to="/">
        <img className="logo" src={assets.logo} alt="طلباتي" />
      </Link>
      {!showSearch && (
        <ul className="navbar-menu">
          <Link
            to="/"
            onClick={() => setMenu("home")}
            className={`${menu === "home" ? "active" : ""}`}
          >
            الرئيسية
          </Link>
          <span
            onClick={() => {
              setMenu("menu");
              navigate("/");
              setTimeout(() => {
                document
                  .getElementById("explore-menu")
                  ?.scrollIntoView({ behavior: "smooth" });
              }, 100);
            }}
            className={`${menu === "menu" ? "active" : ""}`}
          >
            قائمة الطعام
          </span>
          <span
            onClick={() => {
              setMenu("mob-app");
              navigate("/");
              setTimeout(() => {
                document
                  .getElementById("app-download")
                  ?.scrollIntoView({ behavior: "smooth" });
              }, 100);
            }}
            className={`${menu === "mob-app" ? "active" : ""}`}
          >
            تطبيق الهاتف
          </span>
          <span
            onClick={() => {
              setMenu("contact");
              navigate("/");
              setTimeout(() => {
                document
                  .getElementById("footer")
                  ?.scrollIntoView({ behavior: "smooth" });
              }, 100);
            }}
            className={`${menu === "contact" ? "active" : ""}`}
          >
            تواصل معنا
          </span>
        </ul>
      )}
      <div className="navbar-right">
        {!showSearch && (
          <img
            src={assets.search_icon}
            alt="بحث"
            onClick={() => setShowSearch(true)}
            style={{ cursor: "pointer" }}
          />
        )}

        {showSearch && (
          <div className="search-container">
            <input
              type="text"
              className="search-box-large"
              placeholder={`ابحث عن ${placeholder}`}
              onChange={(e) => {
                const value = e.target.value;
                setSearchQuery?.(value);

                if (value.trim() === "") {
                  setShowSearch(false);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  setShowSearch(false);
                }
              }}
            />

            <span
              className="close-btn"
              onClick={() => {
                setShowSearch(false);
                setSearchQuery?.("");
                navigate("/");
              }}
            >
              ✖
            </span>
          </div>
        )}

        <Link to="/cart" className="navbar-search-icon">
          <img src={assets.basket_icon} alt="السلة" />
          <div className={getTotalCartAmount() > 0 ? "dot" : ""}></div>
        </Link>

        {user ? (
          <div className="navbar-profile">
            <img src={assets.profile_icon} alt="الحساب" />
            <ul className="navbar-profile-dropdown">
              <div className="profile-user-info">
                <h4>{user.name}</h4>
                <p>{user.email}</p>
              </div>

              <hr />

              <li onClick={() => navigate("/profile")}>
                <span>👤</span>
                <p>ملفي الشخصي</p>
              </li>

              <li onClick={() => navigate("/myorders")}>
                <img src={assets.bag_icon} alt="" />
                <p>طلباتي</p>
              </li>

              <hr />

              <li onClick={() => setUser?.(null)}>
                <img src={assets.logout_icon} alt="" />
                <p>تسجيل الخروج</p>
              </li>
            </ul>
          </div>
        ) : (
          <button onClick={() => setShowLogin(true)}>
            تسجيل الدخول
          </button>
        )}
      </div>
    </div>
  );
};

export default Navbar;
