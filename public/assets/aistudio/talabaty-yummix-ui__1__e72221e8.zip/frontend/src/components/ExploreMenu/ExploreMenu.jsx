import React, { useContext } from "react";
import "./ExploreMenu.css";
import { StoreContext } from "../../Context/StoreContext";

const categoryLabels = {
  "All": "الكل",
  "Biriyani": "برياني",
  "Rolls": "ساندوتشات رول",
  "Deserts": "حلويات",
  "Sandwich": "ساندوتشات",
  "Cake": "كيك وحلويات",
  "Pure Veg": "نباتي",
  "Pasta": "باستا ومكرونات",
  "Noodles": "نودلز",
  "Pizza": "بيتزا",
  "Snacks": "مقبلات وسناكس",
  "Beverages": "مشروبات",
  "Breakfast": "إفطار",
  "Chinese": "مأكولات آسيوية",
  "Thali": "أطباق ثالي",
  "Others": "أطباق متنوعة",
};

const ExploreMenu = ({ category, setCategory }) => {
  const { menu_list } = useContext(StoreContext);

  return (
    <div className="explore-menu" id="explore-menu">
      <h1>استكشف تشكيلتنا الشهية اليوم</h1>
      <p className="explore-menu-text">
        تصفح، اختر، واطلب وجبتك المفضلة بنقرة واحدة فقط!
      </p>

      <div className="explore-menu-list">
        <div
          className="explore-menu-list-item"
          onClick={() => setCategory("All")}
        >
          <div className={`all-icon ${category === "All" ? "active" : ""}`}>
            🍽
          </div>
          <p>الكل</p>
        </div>

        {menu_list && menu_list.length > 0 ? (
          menu_list.map((item, index) => (
            <div
              key={index}
              className="explore-menu-list-item"
              onClick={() =>
                setCategory((prev) =>
                  prev === item.menu_name ? "All" : item.menu_name
                )
              }
            >
              <img
                src={item.menu_image}
                className={category === item.menu_name ? "active" : ""}
                alt={categoryLabels[item.menu_name] || item.menu_name}
              />
              <p>{categoryLabels[item.menu_name] || item.menu_name}</p>
            </div>
          ))
        ) : (
          <div className="explore-menu-empty-note" style={{ padding: "12px 20px", color: "#6b7280", fontSize: "14px", display: "flex", alignItems: "center", gap: "8px" }}>
            <span>📋</span>
            <span>لا توجد تصنيفات طعام متاحة حالياً.</span>
          </div>
        )}
      </div>
      <hr />
    </div>
  );
};

export default ExploreMenu;
