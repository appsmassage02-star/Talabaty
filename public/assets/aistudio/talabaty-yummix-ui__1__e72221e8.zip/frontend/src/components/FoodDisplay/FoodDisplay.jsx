import React, { useContext } from "react";
import "./FoodDisplay.css";
import FoodItem from "../FoodItem/FoodItem";
import { StoreContext } from "../../Context/StoreContext";
import placeholder from "../../assets/placeholder.webp";

const FoodDisplay = ({ category, searchQuery, foods, restaurantName }) => {
  const { food_list = [], restaurants = [] } = useContext(StoreContext);

  const displayFoods = foods || food_list;
  const query = (searchQuery || "").toLowerCase().trim();

  const filteredFood = displayFoods
    .map((item) => {
      if (!query) return { ...item, priority: 1 };

      const name = (item.name || "").toLowerCase();
      const cat = (item.category || "").toLowerCase();

      let priority = 0;

      if (cat.includes(query)) priority = 3;
      else if (name.startsWith(query)) priority = 2;
      else if (name.includes(query)) priority = 1;

      return { ...item, priority };
    })
    .filter((item) => {
      const matchesCategory = category === "All" || item.category === category;
      return item.priority > 0 && matchesCategory;
    })
    .sort((a, b) => b.priority - a.priority);

  const renderFoodItem = (item) => {
    const restaurant = restaurants.find((r) => r._id === item.restaurantId);

    return (
      <FoodItem
        key={item._id || item.id}
        id={item._id || item.id}
        image={item.image || placeholder}
        name={item.name}
        desc={item.description}
        price={item.price}
        restaurantName={restaurant?.restaurantName}
        prepTime={item.prepTime}
        spiceLevel={item.spiceLevel}
        tags={item.tags}
        avgRating={item.avgRating || 0}
        ratingCount={item.ratingCount || 0}
      />
    );
  };

  return (
    <div className="food-display" id="food-display">
      <h2>
        {searchQuery
          ? `نتائج البحث عن "${searchQuery}"`
          : restaurantName
            ? `أفضل ترشيحات ${restaurantName}`
            : "أشهى الأطباق الأكثر طلباً بالقرب منك"}
      </h2>

      <div className="food-display-list">
        {filteredFood.length > 0 ? (
          filteredFood.map(renderFoodItem)
        ) : (
          <div
            className="food-display-empty-state"
            style={{
              gridColumn: "1 / -1",
              textAlign: "center",
              padding: "48px 20px",
              background: "#fafafa",
              borderRadius: "16px",
              border: "1px dashed #d1d5db",
            }}
          >
            <div style={{ fontSize: "40px", marginBottom: "12px" }}>🍲</div>
            <h3 style={{ color: "#374151", marginBottom: "8px", fontSize: "18px" }}>
              {query
                ? "لم يتم العثور على أطباق مطابقة للبحث"
                : "لا توجد منتجات أو أطباق متاحة حالياً"}
            </h3>
            <p style={{ color: "#6b7280", fontSize: "14px", margin: 0 }}>
              {query
                ? "جرّب البحث باسم طبق أو تصنيف آخر."
                : "سيتم عرض قائمة الوجبات والأطباق هنا فور توفر بيانات المنتجات."}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default FoodDisplay;
