import React, { useState } from "react";
import "./RatingModal.css";
import StarRating from "../StarRating/StarRating";
import { toast } from "react-toastify";

const RatingModal = ({ order, onClose }) => {
  const [ratings, setRatings] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const handleStar = (foodId, stars) => {
    setRatings((prev) => ({ ...prev, [foodId]: stars }));
  };

  const handleSubmit = () => {
    if (Object.keys(ratings).length === 0) {
      toast.error("يرجى اختيار تقييم لصنف واحد على الأقل");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("تم إرسال التقييم بنجاح، شكراً لرأيك القيم!");
      onClose();
    }, 400);
  };

  const items = order?.items || [];

  const uniqueItems = items.filter(
    (item, idx, arr) =>
      arr.findIndex((i) => (i._id || i.id) === (item._id || item.id)) === idx
  );

  return (
    <div className="rating-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="rating-modal">
        {/* Header */}
        <div className="rating-modal-header">
          <div>
            <h2>تقييم أطباق الطلب</h2>
            <p>كيف كانت وجبتك؟ رأيك يساعدنا ويساعد باقي العملاء.</p>
          </div>
          <button className="rating-close" onClick={onClose}>✕</button>
        </div>

        {/* Items */}
        <div className="rating-items">
          {uniqueItems.map((item) => {
            const foodId = item._id || item.id;
            const currentStars = ratings[foodId] || 4;

            return (
              <div key={foodId} className="rating-item">
                {item.image && <img src={item.image} alt={item.name} />}
                <div className="rating-item-info">
                  <h4>{item.name}</h4>
                  <p>الكمية: {item.quantity} · {item.price} ج.م</p>
                </div>
                <div className="rating-item-stars">
                  <StarRating
                    rating={currentStars}
                    interactive
                    size="lg"
                    onRate={(stars) => handleStar(foodId, stars)}
                  />
                  {currentStars > 0 && (
                    <span className="star-label">
                      {["", "ضعيف", "مقبول", "جيد", "رائع", "ممتاز"][currentStars]}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="rating-modal-footer">
          <button className="btn-cancel" onClick={onClose}>إلغاء</button>
          <button
            className="btn-submit-rating"
            onClick={handleSubmit}
            disabled={submitting}
          >
            {submitting ? "جاري الإرسال..." : "إرسال التقييم"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default RatingModal;
