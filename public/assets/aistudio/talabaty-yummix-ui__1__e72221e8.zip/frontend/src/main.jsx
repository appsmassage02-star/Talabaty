import React, { Component } from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { BrowserRouter } from 'react-router-dom'
import StoreContextProvider from './Context/StoreContext'

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("UI Rendering Error caught by ErrorBoundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: "60px 20px", textAlign: "center", fontFamily: "Roboto, sans-serif" }}>
          <h2 style={{ color: "#1a1a2e", marginBottom: "12px", fontSize: "24px" }}>تعذر تحميل الصفحة بشكل سليم</h2>
          <p style={{ color: "#6b7280", marginBottom: "20px", fontSize: "14px" }}>
            {this.state.error?.message || "حدث خطأ غير متوقع أثناء عرض الواجهة."}
          </p>
          <button
            onClick={() => window.location.reload()}
            style={{
              padding: "12px 28px",
              backgroundColor: "#f9c400",
              color: "#1a1a2e",
              fontWeight: 700,
              border: "none",
              borderRadius: "10px",
              cursor: "pointer",
              fontSize: "14px"
            }}
          >
            إعادة تحميل الصفحة
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <ErrorBoundary>
    <BrowserRouter>
      <StoreContextProvider>
        <App />
      </StoreContextProvider>
    </BrowserRouter>
  </ErrorBoundary>,
)
