import React, { createContext, useState } from "react";
import { menu_list, food_list as defaultFoodList } from "../assets/assets";

export const StoreContext = createContext(null);

const StoreContextProvider = ({ children }) => {
  // Pure UI state: Empty data stores ready for real Talabaty API integration
  const [food_list, setFoodList] = useState(defaultFoodList || []);
  const [restaurants, setRestaurants] = useState([]);
  const [nearbyRestaurants, setNearbyRestaurants] = useState([]);

  // Empty cart state
  const [cartItems, setCartItems] = useState({});

  // Empty orders state
  const [orders, setOrders] = useState([]);

  // UI modal and quick checkout states
  const [showLogin, setShowLogin] = useState(false);
  const [showQuickCheckout, setShowQuickCheckout] = useState(false);
  const [quickItem, setQuickItem] = useState(null);
  const [discount, setDiscount] = useState(0);
  const [couponCode, setCouponCode] = useState("");

  // User session state (null = not authenticated)
  const [user, setUser] = useState(null);

  const userLocation = null;

  const addToCart = (itemId) => {
    const addedFood = food_list.find(
      (food) => food._id === itemId || food.id === itemId
    );
    setCartItems((prev) => ({ ...prev, [itemId]: (prev[itemId] || 0) + 1 }));
    if (addedFood) {
      setQuickItem(addedFood);
      setShowQuickCheckout(true);
    }
  };

  const removeFromCart = (itemId) => {
    setCartItems((prev) => {
      const updated = { ...prev };
      if (updated[itemId] > 1) {
        updated[itemId] -= 1;
      } else {
        delete updated[itemId];
      }
      return updated;
    });
  };

  const getTotalCartAmount = () => {
    let total = 0;
    for (const id in cartItems) {
      if (cartItems[id] > 0) {
        const item = food_list.find((p) => p._id === id || p.id === id);
        if (item) total += item.price * cartItems[id];
      }
    }
    return total;
  };

  const contextValue = {
    food_list,
    setFoodList,
    restaurants,
    setRestaurants,
    nearbyRestaurants,
    setNearbyRestaurants,
    userLocation,
    menu_list,
    cartItems,
    setCartItems,
    addToCart,
    removeFromCart,
    getTotalCartAmount,
    showQuickCheckout,
    setShowQuickCheckout,
    quickItem,
    setQuickItem,
    discount,
    setDiscount,
    couponCode,
    setCouponCode,
    showLogin,
    setShowLogin,
    user,
    setUser,
    orders,
    setOrders,
  };

  return (
    <StoreContext.Provider value={contextValue}>
      {children}
    </StoreContext.Provider>
  );
};

export default StoreContextProvider;
